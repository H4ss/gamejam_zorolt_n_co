Credit: Molly "Cougarmint" Willits
Created by hand using Photoshop Educational Edition 6.0.

Licence: CC-BY 3.0.

Free Commercial Use: Yes
Free Personal Use: Yes

Included in this Pack:
easterndragon.png
easterndragon_lrg.png

Donations: Not needed, but appreciated. Contact me if you'd like to make a donation.